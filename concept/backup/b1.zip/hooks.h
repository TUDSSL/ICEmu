#ifndef HOOKS_H_
#define HOOKS_H_

#include <iostream>
#include <boost/icl/interval_map.hpp>

#include <list>
#include <cstdint>

#include <boost/icl/interval_set.hpp>

//typedef void (*uc_cb_hookmem_t)(uc_engine *uc, uc_mem_type type,
//        uint64_t address, int size, int64_t value, void *user_data);

// typedef void (*uc_cb_hookcode_t)(uc_engine *uc, uint64_t address, uint32_t size, void *user_data);


typedef uint32_t armaddr_t;

// Base class
class Hook {
    public:
        enum hook_type {
            UNINITIALIZED,
            RANGE,
            ALL,
        };

        struct hook_arg {
            //Emulator *emu;
            armaddr_t address;
            armaddr_t size;
        };

        std::string name;
        armaddr_t low;
        armaddr_t high;
        enum hook_type type = UNINITIALIZED;

        explicit Hook(std::string hookname, armaddr_t addrlow, armaddr_t addrhigh) {
            type = RANGE;
            name = hookname;
            low = addrlow;
            high = addrhigh;
        }

        explicit Hook(std::string hookname) {
            type = ALL;
            name = hookname;
        }

        //virtual void run(void) {
        //    std::cout << "Running base hook: " << name << std::endl;
        //}
};

/*
 * Code Hook
 * Alias, currently the same as the base class
 */
class HookCode : public Hook {
    using Hook::Hook; // Inherit constructor

    public:
        typedef struct hook_arg hook_arg_t;

        void run(hook_arg_t *arg) {
            std::cout << "[" << arg->address << "] ";
            std::cout << "Running code hook: " << name << std::endl;
        }
};

/*
 * Memory Hook
 */
class HookMemory : public Hook {
    using Hook::Hook; // Inherit constructor

    public:
        enum memory_type {
            MEM_READ,
            MEM_WRITE,
        };

        typedef struct hook_memory_arg : hook_arg {
            enum memory_type mem_type;
            armaddr_t value;
        } hook_arg_t;

        void run(hook_arg_t *arg) {
            std::cout << "[" << arg->address << " <- " << arg->value << "] ";
            std::cout << "Running memory hook: " << name << std::endl;
        }
};

class HooksBase {
    private:
        typedef boost::icl::interval<armaddr_t> hookinterval_t;
        typedef std::set<Hook *> hookset_t;
        typedef boost::icl::interval_map<armaddr_t, hookset_t> interval_hookset_t;

    protected:
        hookset_t hooks_all;
        interval_hookset_t hooks_interval;

    public:
        void add(Hook *hook) {
            hooks_interval.add(
                    make_pair(hookinterval_t::closed(hook->low, hook->high), hookset_t {hook})
                    );
        }

        //template <class T> void run(armaddr_t address, T arg) {
        //    for (const auto &h : hooks_interval(address)) {
        //        h->run(&arg);
        //    }
        //}
};

template <class T>
class Hooks : public HooksBase {
    public:
        void run(armaddr_t address, typename T::hook_arg_t *arg) {
            for (const auto &h : hooks_interval(address)) {
                T *hk = (T *)h;
                hk->run(arg);
                //h->run(arg);
            }
        }
};

#if 0
template <class T>
class Hooks {
    private:
        typedef boost::icl::interval<armaddr_t> hookinterval_t;
        typedef std::set<T *> hookset_t;
        typedef boost::icl::interval_map<armaddr_t, hookset_t> interval_hookset_t;

        hookset_t hooks_all;
        interval_hookset_t hooks_interval;

    public:
        void add(T *hook) {
            hooks_interval.add(
                    make_pair(hookinterval_t::closed(hook->low, hook->high), hookset_t {hook})
                    );
        }

        void run(armaddr_t address, typename T::hook_arg_t *arg) {
            for (const auto &h : hooks_interval(address)) {
                h->run(arg);
            }
        }
};
#endif

class HookBuilder {
    typedef std::function<void(HooksBase *hooks)> ExtensionCodeFn;
};

class RegisterCodeHook {

};


#endif /* HOOKS_H_ */
