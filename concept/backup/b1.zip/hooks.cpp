#include <iostream>
#include "hooks.h"

using namespace std;

int main()
{
    cout << "Hooks test" << endl;
    HookCode hook_code("Hook Code", 10, 100);
    HookMemory hook_mem_1("Hook Memory 1", 10, 100);
    HookMemory hook_mem_2("Hook Memory 2", 9, 9);

    Hooks<HookCode> code_hooks;
    Hooks<HookMemory> memory_hooks;

    code_hooks.add(&hook_code);
    memory_hooks.add(&hook_mem_1);
    memory_hooks.add(&hook_mem_2);

    cout << "Test hooks" << endl;

    list<armaddr_t> addr = {0, 9, 10, 50, 100, 101, 200};

    for (const auto &a : addr) {
        cout << "Code Address: " << a << endl;
        HookCode::hook_arg_t arg;
        arg.address = a;
        code_hooks.run(a, &arg);
    }

    for (const auto &a : addr) {
        cout << "Mem Address: " << a << endl;
        HookMemory::hook_arg_t arg;
        arg.address = a;
        arg.value = 42;
        memory_hooks.run(a, &arg);
    }
#if 0
    Hook hook1("Hook 1", 10, 100);
    Hook hook2("Hook 2", 2, 5);
    Hook hook3("Hook 3", 51, 100);
    Hook hook4("Hook 4", 50, 50);

    Hooks hooks;
    hooks.add(hook1);
    hooks.add(hook2);
    hooks.add(hook3);
    hooks.add(hook4);

    cout << "Test hooks" << endl;

    list<armaddr_t> addr = {0, 9, 10, 50, 100, 101, 200};

    for (const auto &a : addr) {
        cout << "Address: " << a << endl;
        hooks.run();
    }
#endif
}

