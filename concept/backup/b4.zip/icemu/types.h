#ifndef ICEMU_TYPES_H_
#define ICEMU_TYPES_H_

typedef uint32_t armaddr_t;

#endif /* ICEMU_TYPES_H_ */
