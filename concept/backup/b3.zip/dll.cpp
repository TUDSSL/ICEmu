#include <iostream>
#include "hooks.h"

using namespace std;

#if 0
// Automatically enable the pass.
// http://adriansampson.net/blog/clangpass.html
static void registerStrackPass(const PassManagerBuilder &,
        legacy::PassManagerBase &PM) {
    //PM.add(new RegisterStrackAnnoPass());
    PM.add(new StrackPass());
}

static RegisterStandardPasses
//RegisterMyPass(PassManagerBuilder::EP_EarlyAsPossible, registerStrackPass);
RegisterMyPass(PassManagerBuilder::EP_ModuleOptimizerEarly, registerStrackPass);
#endif

class MyCodeHook : public HookCode {
    public:
        MyCodeHook() : HookCode("My Code Hook", 50, 50) {
            cout << "Constructor my DLL code hook" << endl;
        }

        void run(hook_arg_t *arg) {
            cout << "My DLL code hook: " << name << endl;
        }
};

static void registerMyCodeHook(HookBuilder &HB) {
    HB.add(new MyCodeHook());
}

RegisterCodeHook RegisterMyHook (registerMyCodeHook);
